<!DOCTYPE html>
<html>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for all buttons */
.model-content button, .cancelbtn, .submitbtn {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.model-content button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .submitbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* The Modal (background) */
.modal {
  display: none; 
  position: fixed; 
  z-index: 1; 
  left: 0;
  top: 0;
  width: 100%; 
  height: 100%; 
  overflow: auto; 
  background-color: #474e5d;
  padding-top: 50px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto;
  border: 1px solid #888;
  width: 80%; 
}

/* Style the horizontal ruler */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  font-weight: bold;
  color: #f1f1f1;
}

.close:hover,
.close:focus {
  color: #f44336;
  cursor: pointer;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
<body>

<div id="id01" class="modal">
  <span onclick="cancelAndRedirect()" class="close" title="Close Modal">&times;</span>
  <form class="modal-content" id="addPaintingForm" method ="POST" action="/addnew_process.php">
    <div class="container">
      <h1>New Painting</h1>
      <p>Please fill in this form to create new painting.</p>
      <hr>
    <label for="title"><b>Painting title</b></label>
    <input type="text" placeholder="Enter title" name="title" required>

    <label for="finished"><b>Finished</b></label><br>
    <input type="number" placeholder="Enter finished" name="finished" required>
    
    <br><br><label for="media"><b>Paint media</b></label>
    <input type="text" placeholder="Enter media" name="paintMedia" required>
    
    <label for="name"><b>Artist name</b></label>
    <input type="text" placeholder="Enter name" name="artistName" required>
    
    <label for="style"><b>Style</b></label>
    <input type="text" placeholder="Enter style" name="style" required>
    
    <label for="thumbnail"><b>Thumbnail</b></label><br>
    <input type="file" id="myfile" name="myfile" required><br>

      <div class="clearfix">
        <button type="button" onclick="cancelAndRedirect()" class="cancelbtn">Cancel</button>
        <button type="submit" class="submitbtn">Submit</button>
      </div>
    </div>
  </form>
</div>

<script>
// Function to display the modal form
function displayModal() {
    document.getElementById('id01').style.display = 'block';
}

// Call the function to display the modal form when the page loads
window.onload = function() {
    displayModal();
};

// Close the modal when clicking outside of it
window.onclick = function(event) {
  var modal = document.getElementById('id01');
  if (event.target == modal) {
    window.location.href = 'data.php';
  }
}

window.then(data =>{
  alert(daata)
})
</script>

<script>
document.getElementById("addPaintingForm").addEventListener("submit", function(event) {
    event.preventDefault(); 

    var formData = new FormData(this);

    fetch('addnew_process.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            return response.text();
        }
        throw new Error('Network response was not ok.');
    })
    .then(data => {
        alert(data);
        document.getElementById("addPaintingForm").reset();
    })
    .catch(error => {
        console.error('There was a problem with your fetch operation:', error);
        alert('Error: ' + error.message);
    });
});

function cancelAndRedirect() {
    window.location.href ='data.php';
}
</script>

</body>
</html>
