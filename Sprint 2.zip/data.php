<!DOCTYPE html>
<html>
<head>
  <title>Acme Arts</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>

    .container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      min-height: 100vh; 
    }
    .navbar {
      margin: 0;
      padding: 0;
      overflow: hidden;
      border: 1px solid #e7e7e7;
      background-color: black;
    }
    .navbar ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
    }
    .navbar li {
      float: left;
    }
    .navbar li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    .navbar li a:hover:not(.active) {
      background-color: black;
    }
    .navbar li a.active {
      color: white;
      background-color: #04AA6D;
    }
    .search-container button{
      background: #ddd;
      border: none;
      cursor: pointer;
    }
    .filter-container button{
      background: #ddd;
      border: none;
      cursor: pointer;
      width: 33%;
    }
    table {
      font-family: verdanax;
      border-collapse: collapse;
      width: 100%;
      margin-top: 20px;
    }
    th, td {
      border: 1px solid black;
      padding: 8px;
      text-align: left;
    }
    th {
      background-color: #f2f2f2;
    }
    h1{
      font-family: verdana;
      margin-top: -100px;
      margin-left: 10;
      font-size: 25px;
    }
    .search-container{
      float: right;
      margin-right: 10px;
      text-align: center;
      margin-top: 10px;
    }
    .filter-container select{
      width: 33%
    }
  </style>
</head>
<body>

<nav class="navbar">
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a class="active" href="data.php">Paintings</a></li>
    <li><a href="artists.php">Artists</a></li>
    <li><a href="contact.php">Contact Us</a></li>
</ul>
<div class="search-container">
    <input type="text" placeholder="Painting by title" name="search">
    <button type="button" onClick="myFunction()">Search</button>
  </div>
</nav>

<br><br><br><br><br><br>

<div class="container">
  <h1>Painting Data</h1>
  
  <div class="filter-container">
  <select name="artists" id="artists">
    <option value="allartists">--All Artists--</option>
    <option value="August Renoir"> August Renoir </option>
    <option value="Claude Monet"> Claude Monet </option>
    <option value="Leonardo da Vinci"> Leonardo da Vinci </option>
    <option value="Michelangelo"> Michelangelo </option>
    <option value="Pablo Picasso"> Pablo Picasso </option>
    <option value="Paul Cezanne"> Paul Cezanne </option>
    <option value="Salvador Dali"> Salvador Dali </option>
    <option value="Vincent Van Gogh"> Vincent Van Gogh </option>
  </select>
  
  <select name="styles" id="styles">
    <option value="allstyles">--All Styles--</option>
    <option value="Cubism"> Cubism </option>
    <option value="Impressionism"> Impressionism </option>
    <option value="Mannerism"> Mannerism </option>
    <option value="Portrait"> Portrait </option>
    <option value="Realism"> Realism </option>
    <option value="Still-life"> Still-life </option>
    <option value="Surrealism"> Surrealism </option>
  </select>
  <button type="button" onClick="filterFunction()">Filter</button>

  <br><br>

  <a href="addnew.php" class="btn btn-primary">Insert New</a>
  </div>
 
  <?php
  /* PHP code to fetch and display the data from the database. */
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "acmearts";

  try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      /* Set PDO error to exception */
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $stmt = $conn->prepare("SELECT id, paintingtitle, finished, paintmedia, artistname, style, painting FROM Paintings");
      $stmt->execute();

      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      echo "<table id='paintingTable'>";
      echo "<tr><th>Painting Title</th><th>Finished</th><th>Paint Media</th><th>Artist Name</th><th>Style</th><th>Painting</th></tr>";
      while ($row = $stmt->fetch()) {
          echo "<tr>";
          echo "<td>".$row['paintingtitle']."</td>";
          echo "<td>".$row['finished']."</td>";
          echo "<td>".$row['paintmedia']."</td>";
          echo "<td>".$row['artistname']."</td>";
          echo "<td>".$row['style']."</td>";
          echo '<td>'.'<img src = "data:image/png;base64,' . base64_encode($row['painting']) . '" width = "100px" height = "100px"/>'. '</td>';
          echo '<td><a href="imageInfo.php?image_id='.$row['id'].'" class="btn btn-primary">View</a></td>'; // View button
          echo "</tr>";
      }
      echo "</table>";
  } catch(PDOException $e) {
      echo "Error: " . $e->getMessage();
  }
  $conn = null;
  ?>
</div>

<script>
  function myFunction(){
    var input, filter, table, tr, td, i, txtValue;
    input = document.querySelector("input[name='search']");
    filter = input.value.toUpperCase();
    table = document.getElementById("paintingTable");
    tr = table.getElementsByTagName("tr");
    var found = false;
 
    for (i = 1; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td){
        txtValue = td.textContent || td.innerText;
        if(txtValue.toUpperCase().indexOf(filter) > -1){
          tr[i].style.display = "";
          found = true; 
        } else{
          tr[i].style.display = "none";
        }
      }
    }
 
    if (!found) {
      alert("No matching paintings found.");
    }
  }
</script>

<script>
  function filterFunction(){
    var artistSelect = document.getElementById("artists");
    var styleSelect = document.getElementById("styles");
    var table = document.getElementById("paintingTable");
    var rows = table.getElementsByTagName("tr");
    var artistValue = artistSelect.value;
    var styleValue = styleSelect.value;

    console.log("Selected Artist: " + artistValue);
    console.log("Selected Style: " + styleValue);

    for (var i = 1; i < rows.length; i++) {
      var artistCell = rows[i].getElementsByTagName("td")[3].textContent.trim(); 
      var styleCell = rows[i].getElementsByTagName("td")[4].textContent.trim(); 

      console.log("Row " + i + ": Artist Cell: " + artistCell + ", Style Cell: " + styleCell);

      if ((artistValue === "allartists" || artistCell === artistValue) &&
          (styleValue === "allstyles" || styleCell === styleValue)) {
        rows[i].style.display = ""; 
      } else {
        rows[i].style.display = "none"; 
      }
    }
  }
</script>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
