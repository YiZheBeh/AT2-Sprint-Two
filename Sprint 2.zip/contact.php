<!DOCTYPE html>
<html>
<head>
  <title>Acme Arts</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    
    .navbar {
      margin: 0;
      padding: 0;
      overflow: hidden;
      border: 1px solid #e7e7e7;
      background-color: black;
    }
    .navbar ul {
      list-style-type: none; 
      margin: 0;
      padding: 0;
    }
    .navbar li {
      float: left;
    }
    .navbar li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    .navbar li a:hover:not(.active) {
      background-color: black;
    }
    .navbar li a.active {
      color: white;
      background-color: #04AA6D;
    }
    .center{
      text-align: center;
      padding: 110px 0;

    }
    h1{
      font-style: normal;
      font-weight: 700;
      text-align: center;
      font-family: 'US Headline', 'Helvetica Neue', Arial, 'Lucida Grande', sans-serif;
    }
    h2{
      font-style: normal;
      text-align: center;
      font-family: 'US Headline', 'Helvetica Neue', Arial, 'Lucida Grande', sans-serif;
    }
    h3{
      font-style: normal;
      text-align: center;
      font-family: 'US Headline', 'Helvetica Neue', Arial, 'Lucida Grande', sans-serif;
    }
    p{
      font-size: 18px;
      font-family: 'Sweet Sans Pro Regular', 'Helvetica Neue', Arial, 'Lucida Grande', sans-serif;
    }
  </style>
</head>
<body>

<nav class="navbar">
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="data.php">Paintings</a></li>
    <li><a href="artists.php">Artists</a></li>
    <li><a class="active" href="contact.php">Contact Us</a></li>
  </ul>
</nav>

<div class="center">

<h1>CONTACT US</h1>
<h2><strong>NEED HELP?</strong></h2>

<p><a href="tel:1300123456">Call 1300 123 456</a> or Chat between 9am - 6pm AEST Monday to Friday <br> and 9am - 2pm AEST Saturday & Sunday.</p>
<p>Email <a href="mailto:help@acmearts.com">help@acemearts.com</a> at any time and we will response as <br> soon as possible between the hours above.</p>
<p>Please note,our Help Centre is closed during Public <br> Holidays.</p>
<p>Our customer experience team is receiving a higher than usual volume <br> of messages. Please ensure you're calling and live chatting <br> within business hour,our friendly team will get back to you within 48 hours</p>

<h3><strong>More Information</strong></h3>
<p>Please visit <a href="https://www.citems.com.au/">CITE Managed Services</a> for more information.</p>

<img src="images/logo.PNG">
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>