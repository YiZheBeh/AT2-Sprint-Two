<!DOCTYPE html>
<html>
<head>
    <title>Painting Information</title>
    <style>
        .container {
            text-align: center;
            margin-top: 50px;
        }
        .painting-info {
            margin-bottom: 20px;
        }
        .painting-img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <?php
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "acmearts";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Check if the image ID is provided in the URL
        if (isset($_GET['image_id'])) {
            $image_id = $_GET['image_id'];

            // Retrieve painting information from the database based on the image ID
            $stmt = $conn->prepare("SELECT * FROM Paintings WHERE id = :id");
            $stmt->bindParam(':id', $image_id);
            $stmt->execute();
            $painting = $stmt->fetch(PDO::FETCH_ASSOC);

            // Display painting information
            if ($painting) {
                echo "<div class='painting-info'>";
                echo "<h2>".$painting['PaintingTitle']."</h2>";
                echo "<p>Artist: ".$painting['ArtistName']."</p>";
                echo "<p>Style: ".$painting['Style']."</p>";
                echo "<p>Paint Media: ".$painting['PaintMedia']."</p>";
                echo "</div>";
                
                // Display the image with a link to the original image file
                echo "<a href='data:image/png;base64,".base64_encode($painting['Painting'])."' target='_blank'>";
                echo "<img class='Painting-img' src='data:image/png;base64,".base64_encode($painting['Painting'])."' width='500' height='500'>";
                echo "</a>";
            } else {
                echo "Painting not found.";
            }
        } else {
            echo "Image ID not provided.";
        }
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    // Close the database connection
    $conn = null;
    ?>
</div>

</body>
</html>