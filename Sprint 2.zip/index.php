<!DOCTYPE html>
<html>
<head>
  <title>Acme Arts</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    
    .navbar {
      margin: 0;
      padding: 0;
      overflow: hidden;
      border: 1px solid #e7e7e7;
      background-color: black;
    }
    .navbar ul {
      list-style-type: none; 
      margin: 0;
      padding: 0;
    }
    .navbar li {
      float: left;
    }
    .navbar li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    .navbar li a:hover:not(.active) {
      background-color: black;
    }
    .navbar li a.active {
      color: white;
      background-color: #04AA6D;
    }
    .center{
      text-align: center;
      padding: 110px 0;

    }
    .center{
      text-align: center;
      padding: 110px 0;

    }
    h1{
      font-size: 80px;
      font-style: normal;
      font-weight: 700;
      text-align: center;
      font-family: 'US Headline', 'Helvetica Neue', Arial, 'Lucida Grande', sans-serif;
    }
    p{
      font-size: 23px;
      font-family: 'Sweet Sans Pro Regular', 'Helvetica Neue', Arial, 'Lucida Grande', sans-serif;
    }
  </style>
</head>
<body>

<nav class="navbar">
  <ul>
    <li><a class="active" href="index.php">Home</a></li>
    <li><a href="data.php">Paintings</a></li>
    <li><a href="artists.php">Artists</a></li>
    <li><a href="contact.php">Contact Us</a></li>
  </ul>
</nav>

<div class="center">
<img src="images/logo.PNG" width="350" height="300">

<h1><strong>Acme Arts</strong></h1>

<p>Welcome to Acme Arts, your gateway to the timeless masterpieces<br>of renowned artists throughout history. Immerse yourself in<br>
   the beauty of the masters, and let their creations inspire and awe you.<br>Start your exploration now and experience the magic of art like never before.</p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>