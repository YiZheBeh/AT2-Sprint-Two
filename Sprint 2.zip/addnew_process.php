<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "acmearts";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "INSERT INTO Paintings (paintingtitle, finished, paintmedia, artistname, style) 
            VALUES (:paintingtitle, :finished, :paintmedia, :artistname, :style)";

    $stmt = $conn->prepare($sql);

    $stmt->bindParam(':paintingtitle', $_POST['title']);
    $stmt->bindParam(':finished', $_POST['finished']);
    $stmt->bindParam(':paintmedia', $_POST['paintMedia']);
    $stmt->bindParam(':artistname', $_POST['artistName']);
    $stmt->bindParam(':style', $_POST['style']);

    $stmt->execute();
    echo "Painting added successfully!";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
